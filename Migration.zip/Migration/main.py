import base64
import functions_framework
from google.cloud import bigquery
from datetime import datetime
import mysql.connector
import pandas as pd
import pytz
import pyarrow

# BigQuery settings
project_id = 'cs-host-250323f4c1e749beab0804'  
dataset_id = 'AutoZone_POC'  
table_id = 'poc2_table'

# BigQuery schema
schema = [
    bigquery.SchemaField("table_name", "STRING", mode="REQUIRED"),
    bigquery.SchemaField("source_count", "INTEGER", mode="REQUIRED"),
    bigquery.SchemaField("destination_count", "INTEGER", mode="REQUIRED"),
    bigquery.SchemaField("status", "STRING", mode="REQUIRED"),
    bigquery.SchemaField("validation_date", "DATETIME", mode="REQUIRED"),
]

# Initialize BigQuery client with project ID
client = bigquery.Client(project=project_id)

@functions_framework.cloud_event
def validate_data(cloud_event):
    # Connect to the source MySQL database
    source_db = mysql.connector.connect(
        host="34.93.5.47",  # Replace with source VM IP
        user="autozone",
        password="root",
        database="innominds"
    )
    
    # Connect to the destination Cloud SQL MySQL database
    dest_db = mysql.connector.connect(
        host="34.47.198.176",  # Replace with destination Cloud SQL IP
        user="Autozone",
        password="root",
        database="innominds"
    )
    
    # List of tables to validate
    tables = ["departments", "employees"]  # Replace with actual table names
    
    # Run validation and collect results
    validation_results = []
    for table in tables:
        source_cursor = source_db.cursor()
        dest_cursor = dest_db.cursor()
        
        source_cursor.execute(f"SELECT COUNT(*) FROM {table}")
        source_count = source_cursor.fetchone()[0]
        
        dest_cursor.execute(f"SELECT COUNT(*) FROM {table}")
        dest_count = dest_cursor.fetchone()[0]
        
        validation_results.append({
            "table_name": table,
            "source_count": source_count,
            "destination_count": dest_count,
            "status": "Match" if source_count == dest_count else "Mismatch",
            "validation_date": datetime.now(pytz.timezone('Asia/Kolkata'))  # Localize to India timezone
        })
        
        source_cursor.close()
        dest_cursor.close()
    
    source_db.close()
    dest_db.close()
    
    # Ensure that validation results are populated before creating DataFrame
    if validation_results:
        validation_df = pd.DataFrame(validation_results)
        
        # Define dataset and table references
        dataset_ref = client.dataset(dataset_id)
        table_ref = dataset_ref.table(table_id)
        
        # Check if dataset exists or create it
        try:
            client.get_dataset(dataset_ref)
        except:
            client.create_dataset(dataset_ref, exists_ok=True)
        
        # Check if table exists or create it
        table = bigquery.Table(table_ref, schema=schema)
        client.create_table(table, exists_ok=True)
        
        # Insert data into BigQuery and wait for the job to complete
        job = client.load_table_from_dataframe(validation_df, table_ref)
        job.result()  # Wait for the job to complete
        print("Data validation results inserted into BigQuery.")
    else:
        print("No validation results found.")